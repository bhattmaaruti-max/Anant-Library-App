import React,{useEffect,useMemo,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Bell,BookOpen,CalendarCheck,ChevronRight,CircleDollarSign,Clock,DoorOpen,GraduationCap,LayoutDashboard,MapPin,Plus,Search,Settings,ShieldAlert,Trash2,Users,Wallet,X,LogIn,LogOut} from 'lucide-react';
import './styles.css';

const SEATS=40;
const seed=[
 {id:'AL001',name:'Aarav Kumar',phone:'98XXXXXX21',seat:1,joined:'2026-07-01',paid:true,fee:1200,entry:null,exit:null},
 {id:'AL002',name:'Ananya Singh',phone:'97XXXXXX44',seat:2,joined:'2026-07-05',paid:false,fee:1200,entry:null,exit:null},
 {id:'AL003',name:'Rohan Verma',phone:'96XXXXXX87',seat:5,joined:'2026-08-10',paid:true,fee:1200,entry:null,exit:null},
 {id:'AL004',name:'Priya Sharma',phone:'95XXXXXX18',seat:9,joined:'2026-08-15',paid:false,fee:1200,entry:null,exit:null}
];
const money=n=>`₹${Number(n).toLocaleString('en-IN')}`;
const today=()=>new Date().toISOString().slice(0,10);
const now=()=>new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});

function App(){
 const [role,setRole]=useState('admin');
 const [tab,setTab]=useState('dashboard');
 const [students,setStudents]=useState(()=>JSON.parse(localStorage.getItem('anant_students')||'null')||seed);
 const [query,setQuery]=useState('');
 const [showAdd,setShowAdd]=useState(false);
 const [notice,setNotice]=useState('');
 const [selected,setSelected]=useState(null);
 const [early,setEarly]=useState(false);
 useEffect(()=>localStorage.setItem('anant_students',JSON.stringify(students)),[students]);
 const paid=students.filter(s=>s.paid);
 const due=students.filter(s=>!s.paid);
 const present=students.filter(s=>s.entry&&!s.exit);
 const income=paid.reduce((a,s)=>a+Number(s.fee||0),0);
 const occupied=new Set(students.map(s=>s.seat).filter(Boolean));
 const filtered=students.filter(s=>(`${s.name} ${s.id} ${s.phone}`.toLowerCase()).includes(query.toLowerCase()));
 function update(id,patch){setStudents(x=>x.map(s=>s.id===id?{...s,...patch}:s));}
 function attendance(id,type){
   const t=now();
   update(id,type==='entry'?{entry:t,exit:null}:{exit:t});
   setNotice(type==='entry'?'Entry attendance marked':'Exit attendance marked');
   setTimeout(()=>setNotice(''),1800);
 }
 function pay(id){update(id,{paid:true});setNotice('Payment recorded — No dues');setTimeout(()=>setNotice(''),1800)}
 function remove(id){setStudents(x=>x.filter(s=>s.id!==id));}
 return <div className="app">
   <aside className="sidebar">
    <div className="brand"><div className="brandIcon"><BookOpen size={21}/></div><div><b>Anant</b><span>Library App</span></div></div>
    <div className="roleSwitch"><button className={role==='admin'?'active':''} onClick={()=>setRole('admin')}>Admin</button><button className={role==='student'?'active':''} onClick={()=>setRole('student')}>Student</button></div>
    <nav>{(role==='admin'?[['dashboard','Dashboard',LayoutDashboard],['students','Students',Users],['seats','Seats',BookOpen],['attendance','Attendance',CalendarCheck],['payments','Payments',Wallet],['income','Income',CircleDollarSign]]:[['studentHome','My Library',LayoutDashboard],['myAttendance','Attendance',CalendarCheck],['myFees','Fees & Payment',Wallet]]).map(([id,label,I])=><button key={id} className={tab===id?'navActive':''} onClick={()=>setTab(id)}><I size={18}/>{label}</button>)}</nav>
    <div className="sidebarBottom"><button><Settings size={18}/>Settings</button><div className="libraryStatus"><span className="dot"></span><div><b>Library online</b><small>Attendance system ready</small></div></div></div>
   </aside>
   <main className="main">
    <header className="topbar"><div><p className="eyebrow">ANANT LIBRARY</p><h1>{role==='admin'?'Library Admin':'Student Portal'}</h1></div><div className="topActions"><button className="iconBtn" title="Notifications"><Bell size={19}/>{due.length>0&&<i/>}</button><div className="avatar">A</div></div></header>
    {notice&&<div className="toast"><CalendarCheck size={18}/>{notice}</div>}
    {role==='admin'&&tab==='dashboard'&&<AdminDashboard students={students} present={present} due={due} income={income} occupied={occupied} setTab={setTab} setEarly={setEarly} early={early}/>} 
    {role==='admin'&&tab==='students'&&<Students students={filtered} query={query} setQuery={setQuery} add={()=>setShowAdd(true)} update={update} remove={remove} select={setSelected}/>} 
    {role==='admin'&&tab==='seats'&&<Seats students={students} occupied={occupied}/>} 
    {role==='admin'&&tab==='attendance'&&<Attendance students={students} attendance={attendance} present={present}/>} 
    {role==='admin'&&tab==='payments'&&<Payments students={students} pay={pay}/>} 
    {role==='admin'&&tab==='income'&&<Income income={income} students={students}/>} 
    {role==='student'&&(tab==='studentHome'||tab==='myAttendance'||tab==='myFees')&&<StudentPortal students={students} tab={tab} attendance={attendance} pay={pay}/>} 
   </main>
   {showAdd&&<AddStudent close={()=>setShowAdd(false)} add={s=>{setStudents(x=>[...x,s]);setShowAdd(false)}} />}
   {selected&&<StudentDetail student={selected} close={()=>setSelected(null)} />}
 </div>
}

function AdminDashboard({students,present,due,income,occupied,setTab,setEarly,early}){return <section className="page"><div className="welcome"><div><h2>Good morning, Admin 👋</h2><p>Here's what's happening in your library today.</p></div><button className="primary" onClick={()=>setTab('students')}><Plus size={17}/>Add student</button></div>
 <div className="cards"><Stat icon={Users} label="Total Students" value={students.length} sub="Active members"/><Stat icon={CalendarCheck} label="Present Now" value={present.length} sub="Currently in library"/><Stat icon={Wallet} label="Fee Due" value={due.length} sub={`${money(due.reduce((a,s)=>a+s.fee,0))} pending`}/><Stat icon={CircleDollarSign} label="Income" value={money(income)} sub="Recorded payments"/></div>
 <div className="grid2"><div className="panel"><div className="panelHead"><div><h3>Attendance monitor</h3><p>Live entry & exit status</p></div><button className="linkBtn" onClick={()=>setTab('attendance')}>View all <ChevronRight size={15}/></button></div><div className="attendanceRows">{students.slice(0,5).map(s=><div className="row" key={s.id}><div className="miniAvatar">{s.name[0]}</div><div className="rowMain"><b>{s.name}</b><small>Seat {s.seat||'—'} · {s.id}</small></div><span className={s.entry&&!s.exit?'pill green':s.exit?'pill':'pill amber'}>{s.entry&&!s.exit?'Present':s.exit?'Exited':'Not marked'}</span></div>)}</div></div>
 <div className="panel"><div className="panelHead"><div><h3>Seat overview</h3><p>{occupied.size} of {40} seats occupied</p></div><button className="linkBtn" onClick={()=>setTab('seats')}>Manage <ChevronRight size={15}/></button></div><div className="seatMini">{Array.from({length:40},(_,i)=><span key={i} className={occupied.has(i+1)?'busy':''}>{i+1}</span>)}</div><div className="legend"><span><i className="busyDot"/>Occupied</span><span><i className="freeDot"/>Available</span></div></div></div>
 <div className="panel alertPanel"><div className="alertIcon"><ShieldAlert size={20}/></div><div><h3>Illegal entry protection</h3><p>{early?'Early-entry monitoring is ON. Admin alarm will trigger when an arrival is before the allowed time.':'Monitoring is currently OFF. Turn it on when you want early-arrival alerts.'}</p></div><button className={early?'toggle on':'toggle'} onClick={()=>setEarly(!early)}><span/></button></div>
 </section>}
function Stat({icon:I,label,value,sub}){return <div className="stat"><div className="statIcon"><I size={19}/></div><div><span>{label}</span><strong>{value}</strong><small>{sub}</small></div></div>}
function Students({students,query,setQuery,add,update,remove,select}){return <section className="page"><div className="sectionHead"><div><h2>Students</h2><p>Manage student profiles, seats and membership.</p></div><button className="primary" onClick={add}><Plus size={17}/>Add student</button></div><div className="toolbar"><div className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name, ID or phone..."/></div><span className="count">{students.length} students</span></div><div className="panel tablePanel"><table><thead><tr><th>Student</th><th>ID</th><th>Seat</th><th>Joined</th><th>Fee</th><th>Status</th><th></th></tr></thead><tbody>{students.map(s=><tr key={s.id}><td><button className="studentCell" onClick={()=>select(s)}><span className="miniAvatar">{s.name[0]}</span><span><b>{s.name}</b><small>{s.phone}</small></span></button></td><td>{s.id}</td><td><b>#{s.seat||'—'}</b></td><td>{s.joined}</td><td>{money(s.fee)}</td><td><span className={s.paid?'pill green':'pill amber'}>{s.paid?'No dues':'Fee due'}</span></td><td><button className="dangerBtn" onClick={()=>remove(s.id)}><Trash2 size={16}/></button></td></tr>)}</tbody></table></div></section>}
function Seats({students,occupied}){return <section className="page"><div className="sectionHead"><div><h2>Seat management</h2><p>Seat-wise student allocation and availability.</p></div><div className="seatSummary"><b>{40-occupied.size}</b> available <b>{occupied.size}</b> occupied</div></div><div className="panel"><div className="seatGrid">{Array.from({length:40},(_,i)=>{const s=students.find(x=>x.seat===i+1);return <div className={s?'seat occupied':'seat'} key={i}><span>{i+1}</span>{s&&<small>{s.name.split(' ')[0]}</small>}</div>})}</div></div></section>}
function Attendance({students,attendance,present}){return <section className="page"><div className="sectionHead"><div><h2>Attendance monitor</h2><p>Today's entry and exit records.</p></div><span className="live"><i/> LIVE · {present.length} present</span></div><div className="panel tablePanel"><table><thead><tr><th>Student</th><th>Seat</th><th>Entry</th><th>Exit</th><th>Action</th></tr></thead><tbody>{students.map(s=><tr key={s.id}><td><div className="studentCell"><span className="miniAvatar">{s.name[0]}</span><span><b>{s.name}</b><small>{s.id}</small></span></div></td><td>#{s.seat||'—'}</td><td>{s.entry||'—'}</td><td>{s.exit||'—'}</td><td>{!s.entry?<button className="smallBtn" onClick={()=>attendance(s.id,'entry')}><LogIn size={15}/>Mark entry</button>:!s.exit?<button className="smallBtn" onClick={()=>attendance(s.id,'exit')}><LogOut size={15}/>Mark exit</button>:<span className="pill green">Completed</span>}</td></tr>)}</tbody></table></div></section>}
function Payments({students,pay}){const due=students.filter(s=>!s.paid);return <section className="page"><div className="sectionHead"><div><h2>Payments</h2><p>Track monthly fees and dues.</p></div><div className="dueBox"><span>Pending</span><b>{money(due.reduce((a,s)=>a+s.fee,0))}</b></div></div><div className="panel tablePanel"><table><thead><tr><th>Student</th><th>Monthly fee</th><th>Status</th><th></th></tr></thead><tbody>{students.map(s=><tr key={s.id}><td><div className="studentCell"><span className="miniAvatar">{s.name[0]}</span><span><b>{s.name}</b><small>Seat {s.seat||'—'}</small></span></div></td><td>{money(s.fee)}</td><td><span className={s.paid?'pill green':'pill amber'}>{s.paid?'No dues':'Due'}</span></td><td>{s.paid?<span className="muted">Paid</span>:<button className="smallBtn" onClick={()=>pay(s.id)}>Record payment</button>}</td></tr>)}</tbody></table></div></section>}
function Income({income,students}){const paid=students.filter(s=>s.paid);return <section className="page"><div className="sectionHead"><div><h2>Income dashboard</h2><p>Monthly and overall recorded income.</p></div><div className="incomeBig">{money(income)}<small>current records</small></div></div><div className="panel chartPanel"><h3>Payment overview</h3><div className="fakeChart">{[35,55,45,70,60,82,65,90,76,88,72,100].map((h,i)=><div key={i}><span style={{height:`${h}%`}}/><small>{i+1}</small></div>)}</div></div><div className="cards"><Stat icon={CircleDollarSign} label="Paid members" value={paid.length} sub="Recorded as no dues"/><Stat icon={Wallet} label="Average fee" value={money(students.length?students.reduce((a,s)=>a+s.fee,0)/students.length:0)} sub="Per student"/></div></section>}
function StudentPortal({students,tab,attendance,pay}){const s=students[0];return <section className="page"><div className="studentHero"><div className="bigAvatar">{s.name[0]}</div><div><p className="eyebrow">WELCOME BACK</p><h2>{s.name}</h2><p>{s.id} · Seat #{s.seat}</p></div><span className={s.paid?'pill green':'pill amber'}>{s.paid?'No dues':'Fee due'}</span></div>{tab==='studentHome'&&<div className="cards"><Stat icon={MapPin} label="My seat" value={`#${s.seat}`} sub="Assigned seat"/><Stat icon={Clock} label="Entry" value={s.entry||'Not marked'} sub="Today"/><Stat icon={DoorOpen} label="Exit" value={s.exit||'Not marked'} sub="Today"/><Stat icon={Wallet} label="Monthly fee" value={money(s.fee)} sub={s.paid?'Paid':'Payment due'}/></div>}{tab==='myAttendance'&&<div className="panel actionPanel"><h3>Today's attendance</h3><p>Mark your entry when you arrive and exit when you leave.</p><div className="actionBtns"><button className="primary" disabled={!!s.entry} onClick={()=>attendance(s.id,'entry')}><LogIn size={17}/>Mark entry</button><button className="secondary" disabled={!s.entry||!!s.exit} onClick={()=>attendance(s.id,'exit')}><LogOut size={17}/>Mark exit</button></div><small>For production, connect this to verified library location and the admin's attendance server.</small></div>}{tab==='myFees'&&<div className="panel actionPanel"><h3>Monthly fee</h3><div className="feeLine"><span>Current month</span><b>{money(s.fee)}</b></div><p>{s.paid?'Payment recorded. You have no dues.':'Your fee is pending.'}</p>{!s.paid&&<button className="primary" onClick={()=>pay(s.id)}><CircleDollarSign size={17}/>Pay now (demo)</button>}<small>Demo payment only — connect a real payment gateway before accepting money.</small></div>}</section>}
function AddStudent({close,add}){const [f,setF]=useState({name:'',phone:'',seat:'',fee:1200});return <div className="modalBg"><div className="modal"><button className="close" onClick={close}><X/></button><h2>Add student</h2><p>Create a new library member.</p>{[['name','Full name'],['phone','Phone'],['seat','Seat number'],['fee','Monthly fee']].map(([k,l])=><label key={k}>{l}<input value={f[k]} onChange={e=>setF({...f,[k]:e.target.value})} placeholder={l}/></label>)}<button className="primary full" onClick={()=>{if(!f.name)return;add({id:`AL${String(Date.now()).slice(-4)}`,name:f.name,phone:f.phone,seat:Number(f.seat)||null,joined:today(),paid:false,fee:Number(f.fee)||1200,entry:null,exit:null})}}>Save student</button></div></div>}
function StudentDetail({student,close}){return <div className="modalBg"><div className="modal"><button className="close" onClick={close}><X/></button><div className="detailHead"><div className="bigAvatar">{student.name[0]}</div><div><h2>{student.name}</h2><p>{student.id}</p></div></div><div className="details"><span>Phone<b>{student.phone}</b></span><span>Seat<b>#{student.seat||'—'}</b></span><span>Joined<b>{student.joined}</b></span><span>Fee status<b>{student.paid?'No dues':'Due'}</b></span></div></div></div>}
createRoot(document.getElementById('root')).render(<App/>);
