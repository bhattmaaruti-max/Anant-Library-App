# Anant Library App

A starter MVP for a library management app with Admin and Student views.

## Included in this version
- Student add/search/detail/delete
- Seat allocation and seat availability grid (40 demo seats)
- Entry and exit attendance
- Live attendance monitor
- Fee due / no-dues tracking
- Demo payment action
- Income dashboard
- Early-entry protection toggle (UI/demo logic)
- Responsive mobile-friendly UI
- Demo data stored in browser localStorage

## Run locally
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local Vite URL shown in the terminal.

## Important before real deployment
This is an MVP/demo. It does not yet include a real database, authentication, real payment gateway, server-side attendance validation, push notifications, or production geofencing. Add those before using real student records or collecting real payments.

Do not place real student personal data, payment information, passwords, or API keys in a public GitHub repository.
